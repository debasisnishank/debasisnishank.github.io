YT Grab
=======

Download audio or video from YouTube, Instagram, and anywhere else yt-dlp
supports - the whole thing, or just a time range.

INSTALL
-------
Open Terminal, cd into this folder, and run:

    ./install.sh

It installs yt-dlp and ffmpeg via Homebrew if they're missing, copies the
app to ~/Applications, and adds the shell commands to ~/.zshrc.

USING THE APP
-------------
Open "YT Grab" from ~/Applications. Paste a link, pick MP3 or MP4.

For just a section, add a time range after the link:

    https://youtube.com/watch?v=...  1:30-1:45

The range works for both MP3 and MP4.

USING THE TERMINAL
------------------
    ytmp4 URL                 mp4 (H.264, imports into Final Cut)
    ytmp3 URL                 mp3

    ytmp4 URL 1:30 1:45       just that section
    ytmp3 URL 1:30 1:45

    ytclip URL 1:30 1:45      mp4
    ytclip URL 1:30 1:45 mp3  mp3

Timestamps can be 1:30, 01:02:03, or plain seconds (90).

WHERE FILES GO
--------------
/Volumes/Crucial X9/Sound-Effects when that drive is mounted, otherwise
~/Downloads/YT. Override with:  export GRAB_DRIVE=/your/drive

Clips get a _clip suffix so they don't collide with a full download.

NOTE ON THE FIRST LAUNCH
------------------------
This app isn't signed with an Apple Developer certificate. install.sh
clears the quarantine flag for you, so it should open normally. If macOS
still blocks it, right-click the app and choose Open.

REQUIREMENTS
------------
macOS, Homebrew, yt-dlp, ffmpeg. The installer handles the last two.
