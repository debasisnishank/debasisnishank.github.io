#!/bin/zsh
# Install YT Grab. Run from the folder you unzipped:  ./install.sh
set -e

HERE="${0:A:h}"
SHARE="$HOME/.local/share/yt-grab"
APPDIR="$HOME/Applications"

echo "Installing YT Grab…"
echo

# --- dependencies
MISSING=()
command -v yt-dlp >/dev/null 2>&1 || MISSING+=(yt-dlp)
command -v ffmpeg >/dev/null 2>&1 || MISSING+=(ffmpeg)
if [ ${#MISSING[@]} -gt 0 ]; then
  echo "Missing: ${MISSING[*]}"
  if command -v brew >/dev/null 2>&1; then
    echo "Installing with Homebrew…"
    brew install "${MISSING[@]}"
  else
    echo
    echo "YT Grab needs ${MISSING[*]}, and Homebrew isn't installed."
    echo "Install Homebrew from https://brew.sh then re-run this script."
    exit 1
  fi
  echo
fi

# --- engine
mkdir -p "$HOME/.local/bin" "$SHARE"
cp "$HERE/bin/grabmedia" "$HOME/.local/bin/grabmedia"
chmod +x "$HOME/.local/bin/grabmedia"
cp "$HERE/shell/yt-functions.zsh" "$SHARE/yt-functions.zsh"
echo "installed grabmedia -> ~/.local/bin"

# --- app
mkdir -p "$APPDIR"
rm -rf "$APPDIR/YT Grab.app"
cp -R "$HERE/YT Grab.app" "$APPDIR/YT Grab.app"
# Downloaded files carry a quarantine flag; without clearing it macOS refuses
# to open the app because it isn't notarized by an identified developer.
xattr -dr com.apple.quarantine "$APPDIR/YT Grab.app" 2>/dev/null || true
echo "installed YT Grab.app -> ~/Applications"

# --- shell functions
RC="$HOME/.zshrc"
if grep -q "yt-grab/yt-functions.zsh" "$RC" 2>/dev/null; then
  echo "~/.zshrc already loads the shell functions"
else
  printf '\n# ---- YT Grab ----\n[ -r "%s/yt-functions.zsh" ] && source "%s/yt-functions.zsh"\n' \
    "$SHARE" "$SHARE" >> "$RC"
  echo "added shell functions to ~/.zshrc"
fi

# --- PATH check
case ":$PATH:" in
  *":$HOME/.local/bin:"*) ;;
  *) echo
     echo "note: ~/.local/bin isn't on your PATH. Add this to ~/.zshrc:"
     echo '      export PATH="$HOME/.local/bin:$PATH"' ;;
esac

cat <<'DONE'

Done.

  Open "YT Grab" from ~/Applications, paste a link, pick MP3 or MP4.
  For a section, add a range after the link:   <link> 1:30-1:45

  Or from a terminal (run 'exec zsh' first):
    ytmp4 URL              ytmp3 URL
    ytmp4 URL 1:30 1:45    ytmp3 URL 1:30 1:45

Files land on /Volumes/Crucial X9/Sound-Effects if that drive is mounted,
otherwise ~/Downloads/YT. Override with: export GRAB_DRIVE=/your/drive
DONE
