# ---- YouTube downloads for Final Cut (yt-dlp) ----
export YTDRIVE="/Volumes/Crucial X9"   # external drive, if plugged in
export YTDIR="$HOME/Downloads/YT"      # fallback when the drive is unplugged

# Everything lands in Sound-Effects on the Crucial X9 while it's mounted;
# falls back to ~/Downloads/YT when the drive is unplugged.
# (To split video off, return "$YTDRIVE/YT-Clips" when $1 is not "audio".)
_ytdest() {
  if [ -d "$YTDRIVE" ] && [ -w "$YTDRIVE" ]; then
    printf '%s' "$YTDRIVE/Sound-Effects"
  else
    printf '%s' "$YTDIR"
  fi
}

# All three delegate to ~/.local/bin/grabmedia, which the YT Grab app also uses,
# so there's one place to fix things. Works for YouTube and Instagram.

# ytmp4 <url> [start] [end]   -> H.264 mp4, imports straight into FCP
ytmp4() { grabmedia video "$1" "$2" "$3"; }

# ytmp3 <url> [start] [end]   -> mp3 (also the one to use for Instagram audio)
ytmp3() { grabmedia audio "$1" "$2" "$3"; }

# ytclip <url> <start> <end> [mp3|mp4]   -> just that section
#   ytclip URL 1:30 1:45          # mp4 (default)
#   ytclip URL 1:30 1:45 mp3      # mp3
ytclip() {
  if [ $# -lt 3 ]; then
    echo "usage: ytclip <url> <start> <end> [mp3|mp4]    e.g. ytclip 'URL' 1:30 1:45 mp3"
    return 1
  fi
  local kind=video
  case "$4" in
    mp3|audio|a) kind=audio ;;
  esac
  grabmedia "$kind" "$1" "$2" "$3"
}

# toprores <file> [file...]  -> ProRes 422 .mov, if FCP chokes or you want smooth scrubbing
toprores() {
  for f in "$@"; do
    ffmpeg -y -i "$f" -c:v prores_ks -profile:v 3 -pix_fmt yuv422p10le \
      -c:a pcm_s16le "${f%.*}_prores.mov"
  done
}

ytfolder() { local d; d="$(_ytdest video)"; mkdir -p "$d"; open "$d"; }   # open current destination
ytwhere() { echo "video -> $(_ytdest video)"; echo "audio -> $(_ytdest audio)"; }
ytup() { brew upgrade yt-dlp; }                          # run this if downloads start failing
